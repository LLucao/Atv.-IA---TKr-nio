from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import time
import random

app = Flask(__name__, static_folder='.')
CORS(app)

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')

    if username == "admin" and password == "123456":
        return jsonify({"success": True, "message": "Acesso autorizado."})
    else:
        return jsonify({"success": False, "message": "Credenciais inválidas."}), 401

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.get_json() or {}
    msg = data.get('message', '').strip().lower()

    if not msg:
        return jsonify({"error": "Mensagem vazia."}), 400

    time.sleep(0.7)

    cumprimentos = ["olá", "oii", "oiii", "ola", "boa tarde", "bom dia", "boa noite", "opa", "e ai", "eae", "salve", "fala ai", "assistente", "olar"]
    if any(c in msg for c in cumprimentos):
        respostas_ola = [
            "Opa! Beleza? Sistema TKrânio na área. O que manda sobre TI hoje?",
            "Eaí! Tudo certinho por aqui. Qual é a dúvida ou conceito de tecnologia da vez?",
            "Oii! Pronto para codar ou estudar desenvolvimento de sistemas?",
            "Olá! Sistema TKrânio inicializado e operando. Como posso ajudar nos seus estudos?"
        ]
        return jsonify({"reply": random.choice(respostas_ola)})

    pediu_exemplo = any(p in msg for p in ["exemplo", "exemplos", "como faz", "mostra", "manda", "cri"])

    # JAVA
    if "java" in msg:
        if "classe" in msg or "cri" in msg:
            reply = "Para criar uma classe em Java, usamos a palavra reservada `class`. Exemplo:\n\n```java\npublic class Carro {\n    String modelo;\n    int ano;\n}\n```"
        elif "hello" in msg or "mundo" in msg:
            reply = "Veja o clássico Hello World em Java:\n\n```java\npublic class Principal {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, World!\");\n    }\n}\n```"
        elif "variavel" in msg:
            reply = "Em Java, declaramos variáveis informando o tipo antes do nome:\n\n```java\nint idade = 18;\nString nome = \"Carlos\";\n```"
        elif "array" in msg:
            reply = "Exemplo de criação e uso de Array em Java:\n\n```java\nint[] numeros = {1, 2, 3, 4, 5};\nSystem.out.println(numeros[0]);\n```"
        else:
            reply = "O Java é uma linguagem orientada a objetos, robusta e muito utilizada no mercado corporativo e em aplicações Android."

    # HTML
    elif "html" in msg:
        if "tabela" in msg:
            reply = "Exemplo de tabela estruturada em HTML:\n\n```html\n<table>\n  <tr>\n    <th>Nome</th>\n    <th>Idade</th>\n  </tr>\n  <tr>\n    <td>Ana</td>\n    <td>20</td>\n  </tr>\n</table>\n```"
        elif "formulario" in msg or "formulário" in msg:
            reply = "Exemplo de formulário básico em HTML:\n\n```html\n<form action='enviar.php' method='POST'>\n  <label>Nome:</label>\n  <input type='text' name='nome'>\n  <button type='submit'>Enviar</button>\n</form>\n```"
        elif "imagem" in msg:
            reply = "Para inserir uma imagem em HTML, usamos a tag `<img>`:\n\n```html\n<img src='foto.jpg' alt='Descrição da imagem'>\n```"
        elif "link" in msg:
            reply = "Para criar um link (âncora), usamos a tag `<a>`:\n\n```html\n<a href='[https://google.com](https://google.com)' target='_blank'>Acessar Google</a>\n```"
        else:
            reply = "O HTML (HyperText Markup Language) é a linguagem de marcação padrão utilizada para estruturar páginas web."

    # BANCO DE DADOS / SQL
    elif "sql" in msg or "banco de dados" in msg or "mysql" in msg or "tabela" in msg:
        if "select" in msg or "consulta" in msg:
            reply = "Exemplo de consulta SQL (`SELECT`):\n\n```sql\nSELECT nome, email FROM usuarios WHERE idade >= 18;\n```"
        elif "insert" in msg or "inserir" in msg:
            reply = "Exemplo de inserção de dados (`INSERT`):\n\n```sql\nINSERT INTO usuarios (nome, email) VALUES ('Carlos', 'carlos@email.com');\n```"
        elif "update" in msg or "atualizar" in msg:
            reply = "Exemplo de atualização de dados (`UPDATE`):\n\n```sql\nUPDATE usuarios SET email = 'novo@email.com' WHERE id = 1;\n```"
        elif "delete" in msg or "deletar" in msg:
            reply = "Exemplo de exclusão de dados (`DELETE`):\n\n```sql\nDELETE FROM usuarios WHERE id = 1;\n```"
        else:
            reply = "Banco de dados relacional armazena dados em tabelas compostas por linhas e colunas, utilizando a linguagem SQL para consultas."

    # PHP
    elif "php" in msg:
        if "formulario" in msg or "formulário" in msg or "post" in msg:
            reply = "Exemplo de script PHP recebendo dados via método POST:\n\n```php\n<?php\nif ($_SERVER['REQUEST_METHOD'] == 'POST') {\n    $nome = $_POST['nome'];\n    echo 'Olá, ' . $nome;\n}\n?>\n```"
        elif "conexao" in msg or "conexão" in msg:
            reply = "Exemplo de conexão com banco de dados usando PDO no PHP:\n\n```php\n<?php\ntry {\n    $pdo = new PDO('mysql:host=localhost;dbname=sistema', 'root', '');\n    echo 'Conectado com sucesso!';\n} catch (PDOException $e) {\n    echo 'Erro: ' . $e->getMessage();\n}\n?>\n```"
        else:
            reply = "O PHP é uma linguagem de script de código aberto muito utilizada no desenvolvimento web backend."

    # PYTHON
    elif "python" in msg:
        if "print" in msg or "ola" in msg:
            reply = "Exemplo de comando básico em Python:\n\n```python\nprint('Olá, Mundo!')\n```"
        elif "laco" in msg or "repeticao" in msg or "for" in msg:
            reply = "Exemplo de laço de repetição `for` em Python:\n\n```python\nfor i in range(5):\n    print(i)\n```"
        elif "funcao" in msg or "função" in msg:
            reply = "Exemplo de criação de função em Python:\n\n```python\ndef somar(a, b):\n    return a + b\n\nresultado = somar(10, 5)\nprint(resultado)\n```"
        elif "if" in msg or "condicional" in msg:
            reply = "Exemplo de estrutura condicional em Python:\n\n```python\nidade = 18\nif idade >= 18:\n    print('Maior de idade')\nelse:\n    print('Menor de idade')\n```"
        else:
            reply = "Python é uma linguagem de programação de alto nível, interpretada e muito popular em Ciência de Dados, IA e automação."

    # CSS
    elif "css" in msg:
        if "fundo" in msg or "cor" in msg:
            reply = "Exemplo de CSS para mudar a cor de fundo e do texto:\n\n```css\nbody {\n    background-color: #000000;\n    color: #ffffff;\n}\n```"
        elif "centralizar" in msg or "div" in msg:
            reply = "Exemplo usando Flexbox para centralizar elementos:\n\n```css\n.container {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    height: 100vh;\n}\n```"
        else:
            reply = "O CSS (Cascading Style Sheets) é responsável pela estilização visual, layout e cores de páginas web."

    # JAVASCRIPT / REACT
    elif "javascript" in msg or "js" in msg or "react" in msg:
        if "funcao" in msg or "função" in msg:
            reply = "Exemplo de função em JavaScript:\n\n```javascript\nfunction saudar(nome) {\n    return 'Olá, ' + nome;\n}\nconsole.log(saudar('Maria'));\n```"
        elif "react" in msg:
            reply = "Exemplo de componente funcional básico em React:\n\n```jsx\nfunction Botao() {\n    return <button onClick={() => alert('Clicou!')}>Clique Aqui</button>;\n}\n```"
        else:
            reply = "O JavaScript é a principal linguagem de programação para interatividade web, rodando tanto no navegador quanto no servidor (Node.js)."

    # GIT E INFRA / REDES
    elif "git" in msg:
        reply = "O Git é um sistema de controle de versão. Comandos principais:\n- `git init`: Inicia um repositório\n- `git add .`: Prepara os arquivos\n- `git commit -m 'mensagem'`: Salva as alterações\n- `git push`: Envia para o repositório remoto"
    elif "docker" in msg:
        reply = "O Docker é uma ferramenta de containerização que empacota uma aplicação e suas dependências em um ambiente isolado."
    elif "linux" in msg:
        reply = "O Linux é um sistema operacional open-source muito utilizado em servidores. Exemplos de comandos:\n- `ls`: lista arquivos\n- `cd`: navega entre pastas\n- `pwd`: mostra o diretório atual"
    elif "api" in msg:
        reply = "API (Application Programming Interface) é um conjunto de rotas e protocolos que permite a comunicação entre diferentes sistemas ou softwares."
    elif "erro 500" in msg or "erro 404" in msg:
        reply = "O Erro 404 significa que a página solicitada não foi encontrada, enquanto o Erro 500 indica uma falha interna no servidor web."

    else:
        respostas_gerais = [
            f"Compreendi sua pergunta sobre '{msg}'. Como sou especialista em TI, posso te explicar sobre linguagens (Python, Java, PHP), web (HTML, CSS, JS), banco de dados ou Git. Tente perguntar especificamente sobre um desses temas!",
            f"Interessante sua dúvida acerca de '{msg}'. Posso detalhar conceitos técnicos, fornecer exemplos práticos de código ou explicar arquitetura de sistemas. O que prefere?",
            "Boa questão! No ecossistema de Desenvolvimento de Sistemas, esse tema está relacionado à lógica ou infraestrutura. Quer ver um exemplo prático de código sobre isso?"
        ]
        reply = random.choice(respostas_gerais)

    return jsonify({"reply": reply})

if __name__ == '__main__':
    print("⚡ TKrânio rodando em: http://127.0.0.1:5000")
    app.run(debug=True, port=5000)