const API_URL = "http://127.0.0.1:5000/api";

async function handleLogin(event) {
  event.preventDefault();
  const usernameInput = document.getElementById('username').value.trim();
  const passwordInput = document.getElementById('password').value.trim();
  const errorAlert = document.getElementById('login-error');
  const loginBtn = document.getElementById('login-btn');

  loginBtn.innerText = "Entrando...";
  loginBtn.disabled = true;

  try {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: usernameInput, password: passwordInput })
    });

    const data = await response.json();

    if (response.ok && data.success) {
      errorAlert.classList.add('hidden');
      document.getElementById('login-screen').classList.add('hidden');
      document.getElementById('chat-screen').classList.remove('hidden');
    } else {
      errorAlert.innerText = data.message || "Credenciais inválidas.";
      errorAlert.classList.remove('hidden');
    }
  } catch (err) {
    errorAlert.innerText = "Erro: Inicie o app.py no terminal!";
    errorAlert.classList.remove('hidden');
  } finally {
    loginBtn.innerText = "Entrar no Sistema";
    loginBtn.disabled = false;
  }
}

function logout() {
  document.getElementById('chat-screen').classList.add('hidden');
  document.getElementById('login-screen').classList.remove('hidden');
}

function toggleTheme() {
  const htmlTag = document.documentElement;
  const sunIcon = document.getElementById('theme-sun');
  const moonIcon = document.getElementById('theme-moon');

  if (htmlTag.classList.contains('dark')) {
    htmlTag.classList.remove('dark');
    sunIcon.classList.remove('hidden');
    moonIcon.classList.add('hidden');
  } else {
    htmlTag.classList.add('dark');
    sunIcon.classList.add('hidden');
    moonIcon.classList.remove('hidden');
  }
}

function clearChat() {
  const chatBox = document.getElementById('chat-box');
  chatBox.innerHTML = `
    <div class="flex flex-col items-start space-y-1">
      <span class="text-[10px] uppercase tracking-widest text-red-600 font-bold ml-1">TKrânio</span>
      <div class="bg-zinc-900 border border-zinc-800 p-4 rounded-lg max-w-[85%] text-sm leading-relaxed msg-ai">
        Conversa limpa. Sistema pronto para novas perguntas de TI.
      </div>
    </div>
  `;
}

async function sendMessage(event) {
  event.preventDefault();
  const inputField = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');
  const messageText = inputField.value.trim();

  if (!messageText) return;

  const chatBox = document.getElementById('chat-box');

  const userMessageHTML = `
    <div class="flex flex-col items-end space-y-1">
      <span class="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mr-1">Você</span>
      <div class="p-4 rounded-lg max-w-[85%] text-sm leading-relaxed msg-user">
        ${escapeHTML(messageText)}
      </div>
    </div>
  `;
  chatBox.insertAdjacentHTML('beforeend', userMessageHTML);
  inputField.value = '';
  chatBox.scrollTop = chatBox.scrollHeight;

  const loadingId = "loading-" + Date.now();
  const loadingHTML = `
    <div id="${loadingId}" class="flex flex-col items-start space-y-1">
      <span class="text-[10px] uppercase tracking-widest text-red-600 font-bold ml-1">TKrânio</span>
      <div class="p-4 rounded-lg text-sm msg-ai animate-pulse">
        Processando resposta de TI...
      </div>
    </div>
  `;
  chatBox.insertAdjacentHTML('beforeend', loadingHTML);
  chatBox.scrollTop = chatBox.scrollHeight;

  sendBtn.disabled = true;

  try {
    const response = await fetch(`${API_URL}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: messageText })
    });

    const data = await response.json();
    document.getElementById(loadingId).remove();

    const aiReply = data.reply || "Sem resposta.";
    const aiMessageHTML = `
      <div class="flex flex-col items-start space-y-1">
        <span class="text-[10px] uppercase tracking-widest text-red-600 font-bold ml-1">TKrânio</span>
        <div class="p-4 rounded-lg max-w-[85%] text-sm leading-relaxed msg-ai">
          ${escapeHTML(aiReply)}
        </div>
      </div>
    `;
    chatBox.insertAdjacentHTML('beforeend', aiMessageHTML);

  } catch (err) {
    document.getElementById(loadingId).remove();
    const errorHTML = `
      <div class="flex flex-col items-start space-y-1">
        <span class="text-[10px] uppercase tracking-widest text-red-600 font-bold ml-1">TKrânio</span>
        <div class="p-4 rounded-lg text-sm bg-red-950/80 border border-red-800 text-red-300">
          [ERRO]: O servidor Flask (app.py) não está rodando no terminal.
        </div>
      </div>
    `;
    chatBox.insertAdjacentHTML('beforeend', errorHTML);
  } finally {
    sendBtn.disabled = false;
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, 
    tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
  );
}